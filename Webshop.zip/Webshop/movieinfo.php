<!DOCTYPE html>
<html>
<head>

</head>
<?php

include "connection.php";

$movieid = $_GET['movieid'];

$sql = "SELECT * FROM products WHERE id = '$movieid'";
$query = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_array($query)) {
  $moviedatabaseid = $row['id'];
  $movie_title = $row['title'];
  $cover_picture = $row['cover_picture'];
  $backdrop_image = $row['backdrop'];
?>
<body id="movieInfoBody" style="background-image: url(movieBackdrops/'$backdrop_image'); background-repeat: no-repeat; background-size: cover; ">
<?php
echo "<div> 
<img src='movieCovers/{$cover_picture}' alt='Cover Picture of $movie_title'></div>
<ul>
        <li>
          "; echo $moviedatabaseid;"  
        </li>
        
      </ul>";

}

echo $movieid;
?>
<div id='backdrop' style='background: url("/movieBackdrops/the-incredubles-backdrop.jpg"); width: 100px; height: 70px;'></div>


</body>
</html>
